<?php $__env->startSection('main'); ?>
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Réserver</h1>
  <div>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('reservations.store')); ?>">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="name">Nom:</label>
              <input type="text" class="form-control" name="name"/>
          </div>
          <div class="form-group">
              <label for="code">Code:</label>
              <input type="number" class="form-control" name="code"/>
          </div>

          <div class="form-group">
              <label for="author">Auteur</label>
              <input type="text" class="form-control" name="author"/>
          </div>
          <div class="form-group">
              <label for="dated">Date:</label>
              <input type="date" class="form-control" name="dated"/>
          </div>
          <div class="form-group">
              <label for="kind">Genre:</label>
                <select size="2" multiple="multiple" name="kind">
                    <option value="not-available">Manga</option>
                    <option value="free">BD</option>
                    <input type="text" class="form-control" name="kind"/>
                </select>
          </div>
          <div class="form-group">
              <label for="availability">Disponibilité:</label>
                <select size="2" multiple="multiple" name="availability">
                    <option value="not-available">Non disponible</option>
                    <option value="free">Disponible</option>
                    <input type="text" class="form-control" name="availability"/>
                </select>
          </div>
          <button type="submit" class="btn btn-primary-outline">Ajout de la réservations</button>
      </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/reservations/create.blade.php ENDPATH**/ ?>