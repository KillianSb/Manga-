<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <!-- custom -->
  <link rel="stylesheet" href="css/templatemo-style.css">
  <!-- Google font -->
  <link href='//fonts.googleapis.com/css?family=Signika:400,300,600,700' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Chewy' rel='stylesheet' type='text/css'>
</head>

<body class="create_contact_page">


<?php $__env->startSection('main'); ?>
<!-- Header -->
  <header class="header_auth">
    <a href="<?php echo e(route('home')); ?>" class="header_auth">MANGA++</a>
    <a href="<?php echo e(route('home')); ?>" class="return">Retour à l'accueil</a>
  </header>
  <!-- End Header -->
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Ajouter un contact</h1>
  <div>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('contacts.store')); ?>">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="first_name" class="first_name">Nom:</label>
              <input type="text" class="form-control" name="first_name"/>
          </div>

          <div class="form-group">
              <label for="last_name" class="last_name">Prenom:</label>
              <input type="text" class="form-control" name="last_name"/>
          </div>

          <div class="form-group">
              <label for="email" class="email">Email:</label>
              <input type="text" class="form-control" name="email"/>
          </div>
          <div class="form-group">
              <label for="city" class="city">Ville:</label>
              <input type="text" class="form-control" name="city"/>
          </div>
          <div class="form-group">
              <label for="country" class="country">Pays:</label>
              <input type="text" class="form-control" name="country"/>
          </div>
          <div class="form-group">
              <label for="job_title" class="job_title">Travail:</label>
              <input type="text" class="form-control" name="job_title"/>
          </div>
          <button type="submit" class="add_contact">Ajout d'un contact</button>
      </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/contacts/create.blade.php ENDPATH**/ ?>