<?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">reservations</h1>
    <nspan>
    <a style="margin: 19px;" href="<?php echo e(route('reservations.create')); ?>" class="btn btn-primary">Nouvelle reservation</a>
    </nspan>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Auteur</td>
          <td>Genre</td>
          <td>Disponibilité</td>
          <td>Date</td>
          <td>Nom</td>
        </tr>

        <div>
        <span>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Retour à l'accueil</a>
        </span>
        </div>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reservationsuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservationuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($reservationuser->id); ?></td>
            <td><?php echo e($reservationuser->name); ?></td>
            <td><?php echo e($reservationuser->author); ?></td>
            <td><?php echo e($reservationuser->kind); ?></td>
            <td><?php echo e($reservationuser->availability); ?></td>
            <td><?php echo e($reservationuser->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/reservationsuser/index.blade.php ENDPATH**/ ?>