<!DOCTYPE html>
<html>
<head>
    <!-- custom -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <!-- Google font -->
    <link href='//fonts.googleapis.com/css?family=Signika:400,300,600,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Chewy' rel='stylesheet' type='text/css'>
    <meta charset="utf-8">
</head>

<body class="book_page">


<?php $__env->startSection('main'); ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="row">
  <div class="col-sm-12">
    <!-- Header -->
    <header class="header_auth">
        <a href="<?php echo e(route('home')); ?>" class="header_auth">MANGA++</a>
        <a href="<?php echo e(route('home')); ?>" class="return">Retour à l'accueil</a>
    </header>
    <!-- End Header -->
    <h1 class="display-3">Livres</h1>

    <div class="book_container">
    <?php $__currentLoopData = $livresuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livreuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="book">
      <div class="book_image">
        <img src="../public/images/<?php echo e($livreuser->name); ?>_n1.jpg" alt="Book image">
      </div>
      <h2><?php echo e($livreuser->name); ?></h2>
      <h3>Genre: <?php echo e($livreuser->kind); ?></h3>
      <h3>Auteur: <?php echo e($livreuser->author); ?></h3>
      <h4>Date d'édition: <?php echo e($livreuser->dated); ?></h4>
      <a href="<?php echo e(route('reservationsuser.index',$livreuser->name)); ?>" class="btn btn-primary">Réservervations</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <div>
    <?php if(session()->get('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
</div>
</div>
</body>
</html>

<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/livresuser/index.blade.php ENDPATH**/ ?>