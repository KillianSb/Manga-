<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <!-- custom -->
  <link rel="stylesheet" href="css/templatemo-style.css">
  <!-- Google font -->
  <link href='//fonts.googleapis.com/css?family=Signika:400,300,600,700' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Chewy' rel='stylesheet' type='text/css'>
</head>

<body class="contact_page">


<?php $__env->startSection('main'); ?>
  <!-- Header -->
  <header class="header_auth">
    <a href="<?php echo e(route('home')); ?>" class="header_auth">MANGA++</a>
    <a href="<?php echo e(route('home')); ?>" class="return">Retour à l'accueil</a>
  </header>
  <!-- End Header -->
  <div class="row">
    <div class="col-sm-12">
      <h1 class="display-3">Contacts</h1>
        <nspan>
          <a style="margin: 19px;" href="<?php echo e(route('contacts.create')); ?>" class="contact_newContact">Nouveau contact</a>
        </nspan>
      <table class="contact_table">
        <thead>
          <tr>
            <td class="contact_id">ID</td>
            <td class="contact_name">Nom</td>
            <td class="contact_email">Email</td>
            <td class="contact_user_job">Travail</td>
            <td class="contact_user_city">Ville</td>
            <td class="contact_user_country">Pays</td>
            <td colspan = 2 class="contact_actions_title">Actions</td>
          </tr>
        </thead>
      <tbody>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($contact->id); ?></td>
            <td><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></td>
            <td><?php echo e($contact->email); ?></td>
            <td><?php echo e($contact->job_title); ?></td>
            <td><?php echo e($contact->city); ?></td>
            <td><?php echo e($contact->country); ?></td>
            <td class="contact_actions">
                <a href="<?php echo e(route('contacts.edit',$contact->id)); ?>" class="contact_edit">Edit</a>
            </td>
            <td class="contact_actions">
                <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="contact_remove" type="submit">Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <div>
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
</div>
</div>
<!-- Start footer -->
    <footer class="contact_page_footer">
        <div class="contact_footer_container">
            <p>Copyright &copy; 2020 Manga++</p>
            <a href="<?php echo e(route('legal')); ?>" class="legal_notice">Mentions légales</a>
        </div>
    </footer>
<!-- End footer -->
</body>
</html>
<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/contacts/index.blade.php ENDPATH**/ ?>