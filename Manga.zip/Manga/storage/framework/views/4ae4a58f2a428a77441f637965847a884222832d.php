<?php $__env->startSection('main'); ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Livres</h1>
    <nspan>
    <a style="margin: 19px;" href="<?php echo e(route('livres.create')); ?>" class="btn btn-primary">Nouveau livre</a>
    </nspan>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Code</td>
          <td>Auteur</td>
          <td>Date</td>
          <td>Genre</td>
          <td colspan = 2>Actions</td>
        </tr>

        <div>
        <span>
        <a style="margin: 19px;" href="<?php echo e(route('home')); ?>" class="btn btn-primary">Retour home</a>
        </span>
        </div>
    </thead>
    <tbody>
        <?php $__currentLoopData = $livres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($livre->id); ?></td>
            <td><?php echo e($livre->name); ?> <?php echo e($livre->kind); ?></td>
            <td><?php echo e($livre->code); ?></td>
            <td><?php echo e($livre->author); ?></td>
            <td><?php echo e($livre->dated); ?></td>
            <td>
                <a href="<?php echo e(route('livres.edit',$livre->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <form action="<?php echo e(route('livres.destroy', $livre->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Manga\resources\views/livres/index.blade.php ENDPATH**/ ?>